## CONSIGNE

Votre objectif consiste à analyser les différentes applications appXX afin de comprendre leur fonctionnement.

Étapes des analyses (identiques à celles réalisées durant le cours) :

1. Identifier prologue et epilogue ;
2. Identifier tous les "call" ;
3. Identifier tous les arguments des "call" ;
4. Décrire ce que fait le programme ;
5. Écrire un code en pseudo-c qui résume le programme.

## REMARQUE

Durant la phase d'analyse du code assembleur, il n'est pas nécessaire de réaliser la traduction de l'ensemble des instructions, vous devez traduire en priorité les instructions les plus pertinentes qui permettent de comprendre le programme. En moyenne, vous aurez à traduire entre 60 et 80 % des instructions. Lorsque des données importantes (ex : mot de passe) sont manipulées par le programme, il est important de les indiquer.

## RENDU

Vous devez rendre l'ensemble des fichiers *.asm des différents programmes que vous allez analyser dans une archive au format ZIP qui porte le nom et prénom des deux membres du groupe.